package com.neosoft.ilabankassignment

import java.util.Locale

class FilterItemsUseCase {
    fun execute(items: List<ItemData>, query: String): List<ItemData> {
        if (query.isBlank()) return items

        val normalizedQuery = query.trim().lowercase(Locale.getDefault())

        return items.filter { item ->
            item.title.lowercase(Locale.getDefault()).contains(normalizedQuery)
        }
    }
}

class CalculateStatisticsUseCase {
    fun execute(items: List<ItemData>, currentCarouselPage: Int): Statistics {
        val itemsPerPage = mapOf(currentCarouselPage to items.size)

        val topChars = calculateTopCharacters(items.map { it.title })

        return Statistics(
            itemsPerPage = itemsPerPage,
            topCharacters = topChars
        )
    }

    private fun calculateTopCharacters(labels: List<String>): List<CharCount> {
        val charFrequency = mutableMapOf<Char, Int>()

        labels.forEach { label ->
            label.lowercase(Locale.getDefault())
                .filter { it.isLetter() }
                .forEach { char ->
                    charFrequency[char] = charFrequency.getOrDefault(char, 0) + 1
                }
        }

        return charFrequency.entries
            .sortedByDescending { it.value }
            .take(3)
            .map { CharCount(it.key, it.value) }
    }
}
