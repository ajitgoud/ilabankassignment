package com.neosoft.appxml

import android.content.ClipData.Item
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager2.widget.ViewPager2
import com.neosoft.appxml.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val binding: ActivityMainBinding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }
    private lateinit var viewModel: MainViewModel

    private val carouselAdapter: ImageCarouselAdapter by lazy {
        ImageCarouselAdapter()
    }
    private val listAdapter: ItemListAdapter by lazy {
        ItemListAdapter()
    }

    private val indicatorViews = mutableListOf<ImageView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        setupCarousel()
        setupPageIndicators()
        setupList()
        setupSearch()
        setupFab()
        observeViewModel()
    }

    private fun setupCarousel() {
        carouselAdapter.submitList(viewModel.images)
        binding.viewPagerCarousel.adapter = carouselAdapter
        binding.viewPagerCarousel.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                viewModel.onCarouselPageChanged(position)
                updateIndicators(position)
            }
        })
    }

    private fun setupPageIndicators() {
        val indicatorContainer = binding.indicatorContainer
        indicatorContainer.removeAllViews()
        indicatorViews.clear()

        val imageCount = viewModel.images.size

        for (i in 0 until imageCount) {
            val indicator = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    dpToPx(8),
                    dpToPx(8)
                ).apply {
                    setMargins(dpToPx(4), 0, dpToPx(4), 0)
                }

                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(getColor(R.color.indicator_inactive))
                }
            }

            indicatorContainer.addView(indicator)
            indicatorViews.add(indicator)
        }

        if (indicatorViews.isNotEmpty()) {
            updateIndicators(0)
        }
    }

    private fun updateIndicators(position: Int) {
        indicatorViews.forEachIndexed { index, imageView ->
            val drawable = imageView.background as GradientDrawable
            if (index == position) {
                drawable.setColor(getColor(R.color.indicator_active))
            } else {
                drawable.setColor(getColor(R.color.indicator_inactive))
            }
        }
    }

    private fun setupList() {
        binding.recyclerViewItems.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = listAdapter
            isNestedScrollingEnabled = true
        }
    }

    private fun setupSearch() {
        binding.searchEditText.addTextChangedListener { text ->
            viewModel.onSearchQueryChanged(text?.toString() ?: "")
        }
    }

    private fun setupFab() {
        binding.fab.setOnClickListener {
            showStatisticsBottomSheet()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.filteredItems.collect { items ->
                    listAdapter.submitList(items)
                }
            }
        }
    }

    private fun showStatisticsBottomSheet() {
        val statistics = viewModel.getStatistics()
        val bottomSheet = StatisticsBottomSheet(statistics)
        bottomSheet.show(supportFragmentManager, "StatisticsBottomSheet")
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }
}