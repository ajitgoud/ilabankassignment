package com.neosoft.appxml

class DataRepository {

    fun getImages(): List<ImageData> {
        return listOf(
            ImageData(imageResId = R.drawable.image_1),
            ImageData(imageResId = R.drawable.image_2),
            ImageData(imageResId = R.drawable.image_3),
            ImageData(imageResId = R.drawable.image_4),
            ImageData(imageResId = R.drawable.image_5),
            ImageData(imageResId = R.drawable.image_6),
            ImageData(imageResId = R.drawable.image_7),
        )
    }

    fun getItems(): List<ItemData> {
        return listOf(
            ItemData(id = "1", title = "Apple", subtitle = "Fresh & Crisp", imageResId = R.drawable.image_1),
            ItemData(id = "2", title = "Banana", subtitle = "Energy Boost", imageResId = R.drawable.image_2),
            ItemData(id = "3", title = "Orange", subtitle = "Vitamin C", imageResId = R.drawable.image_3),
            ItemData(id = "4", title = "Blueberry", subtitle = "Antioxidant", imageResId = R.drawable.image_4),
            ItemData(id = "5", title = "Strawberry", subtitle = "Sweet & Juicy", imageResId = R.drawable.image_5),
            ItemData(id = "6", title = "Mango", subtitle = "Tropical King", imageResId = R.drawable.image_6),
            ItemData(id = "7", title = "Pineapple", subtitle = "Tangy Fresh", imageResId = R.drawable.image_7),
            ItemData(id = "8", title = "Watermelon", subtitle = "Summer Cool", imageResId = R.drawable.image_1),
            ItemData(id = "9", title = "Grapes", subtitle = "Mini Bites", imageResId = R.drawable.image_2),
            ItemData(id = "10", title = "Cherry", subtitle = "Juicy Pop", imageResId = R.drawable.image_3),
            ItemData(id = "11", title = "Peach", subtitle = "Soft & Sweet", imageResId = R.drawable.image_4),
            ItemData(id = "12", title = "Plum", subtitle = "Deep Flavor", imageResId = R.drawable.image_5),
            ItemData(id = "13", title = "Apricot", subtitle = "Golden Soft", imageResId = R.drawable.image_6),
            ItemData(id = "14", title = "Kiwi", subtitle = "Tangy Green", imageResId = R.drawable.image_7),
            ItemData(id = "15", title = "Papaya", subtitle = "Digestive Aid", imageResId = R.drawable.image_1),
            ItemData(id = "16", title = "Avocado", subtitle = "Healthy Fats", imageResId = R.drawable.image_2),
            ItemData(id = "17", title = "Coconut", subtitle = "Natural Hydration", imageResId = R.drawable.image_3),
            ItemData(id = "18", title = "Raspberry", subtitle = "Tart Berry", imageResId = R.drawable.image_4),
            ItemData(id = "19", title = "Blackberry", subtitle = "Bold Taste", imageResId = R.drawable.image_5),
            ItemData(id = "20", title = "Cranberry", subtitle = "Sharp & Fresh", imageResId = R.drawable.image_6)
        )
    }

}