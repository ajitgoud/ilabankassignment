package com.neosoft.appxml

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.neosoft.appxml.databinding.ItemCarouselImageBinding
import com.neosoft.appxml.databinding.ItemListRowBinding

class ImageCarouselAdapter : ListAdapter<ImageData, ImageCarouselAdapter.ImageViewHolder>(ItemDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val binding = ItemCarouselImageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ImageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ImageViewHolder(private val binding: ItemCarouselImageBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(imageData: ImageData) {
            binding.imageViewCarousel.setImageResource(imageData.imageResId)
        }
    }

    private class ItemDiffCallback : DiffUtil.ItemCallback<ImageData>() {
        override fun areItemsTheSame(oldItem: ImageData, newItem: ImageData): Boolean {
            return oldItem.imageResId == newItem.imageResId
        }

        override fun areContentsTheSame(oldItem: ImageData, newItem: ImageData): Boolean {
            return oldItem == newItem
        }
    }

}

class ItemListAdapter : ListAdapter<ItemData, ItemListAdapter.ItemViewHolder>(ItemDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val binding = ItemListRowBinding.inflate(LayoutInflater.from(parent.context),
            parent,
            false )
        return ItemViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ItemViewHolder(private val binding: ItemListRowBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: ItemData) {
            binding.apply {
                textViewLabel.text = item.title
                textViewSubtitle.text = item.subtitle
                imageViewItem.setImageResource(item.imageResId)
            }
        }
    }

    private class ItemDiffCallback : DiffUtil.ItemCallback<ItemData>() {
        override fun areItemsTheSame(oldItem: ItemData, newItem: ItemData): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ItemData, newItem: ItemData): Boolean {
            return oldItem == newItem
        }
    }
}