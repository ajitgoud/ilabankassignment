package com.neosoft.ilabankassignment

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: DataRepository = DataRepository(),
    private val filterItemsUseCase: FilterItemsUseCase = FilterItemsUseCase(),
    private val calculateStatisticsUseCase: CalculateStatisticsUseCase = CalculateStatisticsUseCase()
) : ViewModel() {

    private val allItems = MutableStateFlow<List<ItemData>>(emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _carouselPosition = MutableStateFlow(0)
    val carouselPosition: StateFlow<Int> = _carouselPosition

    val filteredItems: StateFlow<List<ItemData>> = combine(
        allItems,
        _searchQuery
    ) { items, query ->
        filterItemsUseCase.execute(items, query)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val images = repository.getImages()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            allItems.value = repository.getItems()
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onCarouselPageChanged(position: Int) {
        _carouselPosition.value = position
    }

    fun getStatistics(): Statistics {
        return calculateStatisticsUseCase.execute(
            items = filteredItems.value,
            currentCarouselPage = _carouselPosition.value
        )
    }
}