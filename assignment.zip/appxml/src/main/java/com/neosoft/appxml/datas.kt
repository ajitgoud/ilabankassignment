package com.neosoft.appxml

import androidx.annotation.DrawableRes

data class ItemData(
    val id: String,
    val title: String,
    val subtitle:String,
    @DrawableRes val imageResId: Int
)

data class ImageData(
    @DrawableRes val imageResId: Int
)

data class Statistics(
    val itemsPerPage: Map<Int, Int>,
    val topCharacters: List<CharCount>
)

data class CharCount(
    val char: Char,
    val count: Int
)